
package MODUL3;

import javax.swing.JOptionPane;


public class ApotekMini extends javax.swing.JFrame {
    int jumlah = 0 ;
    int harga ;
    /**
     * Creates new form ApotekMini
     */
    public ApotekMini() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel3 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        o1 = new javax.swing.JCheckBox();
        o2 = new javax.swing.JCheckBox();
        o3 = new javax.swing.JCheckBox();
        o4 = new javax.swing.JCheckBox();
        o5 = new javax.swing.JCheckBox();
        o6 = new javax.swing.JCheckBox();
        o7 = new javax.swing.JCheckBox();
        o8 = new javax.swing.JCheckBox();
        o9 = new javax.swing.JCheckBox();
        o10 = new javax.swing.JCheckBox();
        jLabel23 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        Nama = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        Keluhan = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        TS = new javax.swing.JTextField();
        Uang = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        Kembalian = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        Kurang = new javax.swing.JButton();
        Jumlah = new javax.swing.JTextField();
        Tambah = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Nota = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(255, 255, 204));
        jPanel3.setLayout(new java.awt.BorderLayout());

        jPanel7.setBackground(new java.awt.Color(102, 0, 102));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Kristen ITC", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("INFORMASI OBAT");

        jPanel1.setBackground(new java.awt.Color(255, 255, 102));

        jLabel1.setFont(new java.awt.Font("Matura MT Script Capitals", 1, 36)); // NOI18N
        jLabel1.setText("~~~~~~~Apotek Dani~~~~~~~~");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 617, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(0, 51, 153));
        jPanel4.setLayout(null);

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/amoxcilin.jpg"))); // NOI18N
        jPanel4.add(jLabel24);
        jLabel24.setBounds(30, 10, 64, 43);

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Amoxlin Rp.10.000");
        jPanel4.add(jLabel3);
        jLabel3.setBounds(10, 60, 100, 16);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/antasidadoen.jpg"))); // NOI18N
        jPanel4.add(jLabel4);
        jLabel4.setBounds(200, 20, 64, 31);

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Antasidadoen Rp. 10.000");
        jPanel4.add(jLabel6);
        jLabel6.setBounds(180, 60, 140, 16);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/cetrizine.jpg"))); // NOI18N
        jPanel4.add(jLabel7);
        jLabel7.setBounds(360, 10, 70, 40);

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Cetrizine Rp. 5000");
        jPanel4.add(jLabel5);
        jLabel5.setBounds(350, 60, 100, 16);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/dexametasone.jpg"))); // NOI18N
        jPanel4.add(jLabel8);
        jLabel8.setBounds(30, 90, 64, 43);

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Dexametasone Rp. 15.000");
        jPanel4.add(jLabel9);
        jLabel9.setBounds(0, 150, 150, 16);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/ibuprofen.jpg"))); // NOI18N
        jPanel4.add(jLabel10);
        jLabel10.setBounds(200, 90, 70, 40);

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Ibuprofen Rp. 10.000");
        jPanel4.add(jLabel11);
        jLabel11.setBounds(180, 150, 120, 16);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/loratadine.jpg"))); // NOI18N
        jPanel4.add(jLabel12);
        jLabel12.setBounds(360, 90, 70, 53);

        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Loratadine Rp.20.000");
        jPanel4.add(jLabel13);
        jLabel13.setBounds(330, 150, 130, 16);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/paracetamol1.jpg"))); // NOI18N
        jPanel4.add(jLabel14);
        jLabel14.setBounds(20, 180, 70, 67);

        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Paracetamol Rp. 5.000");
        jPanel4.add(jLabel15);
        jLabel15.setBounds(0, 260, 130, 16);

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/super tetra.jpeg"))); // NOI18N
        jLabel16.setText("jLabel16");
        jPanel4.add(jLabel16);
        jLabel16.setBounds(200, 180, 70, 67);

        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Supertetra Rp.10.000");
        jPanel4.add(jLabel17);
        jLabel17.setBounds(180, 260, 120, 16);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/vitamin c.jpeg"))); // NOI18N
        jLabel18.setText("jLabel18");
        jPanel4.add(jLabel18);
        jLabel18.setBounds(360, 180, 70, 67);

        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Vitamin C Rp. 2000");
        jPanel4.add(jLabel19);
        jLabel19.setBounds(340, 260, 110, 16);

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MODUL3/pontan.jpg"))); // NOI18N
        jPanel4.add(jLabel21);
        jLabel21.setBounds(20, 300, 80, 47);

        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Ponstan Rp. 25.000");
        jPanel4.add(jLabel22);
        jLabel22.setBounds(0, 350, 110, 16);

        jPanel2.setBackground(new java.awt.Color(255, 255, 102));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 73, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 102));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 102));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 73, Short.MAX_VALUE)
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 102));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel20.setFont(new java.awt.Font("Kristen ITC", 1, 24)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("DAFTAR OBAT");

        jPanel10.setBackground(new java.awt.Color(0, 0, 153));
        jPanel10.setLayout(new java.awt.GridBagLayout());

        o1.setForeground(new java.awt.Color(255, 255, 255));
        o1.setText("Amoxilin");
        o1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 45;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(1, 0, 0, 0);
        jPanel10.add(o1, gridBagConstraints);

        o2.setForeground(new java.awt.Color(255, 255, 255));
        o2.setText("Antasidadoen");
        o2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o2ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 18;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(1, 0, 0, 1);
        jPanel10.add(o2, gridBagConstraints);

        o3.setForeground(new java.awt.Color(255, 255, 255));
        o3.setText("Cetrizine");
        o3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o3ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 46;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        jPanel10.add(o3, gridBagConstraints);

        o4.setForeground(new java.awt.Color(255, 255, 255));
        o4.setText("Dexametasone");
        o4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o4ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 13;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 1);
        jPanel10.add(o4, gridBagConstraints);

        o5.setForeground(new java.awt.Color(255, 255, 255));
        o5.setText("Ibuprofen");
        o5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o5ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 38;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        jPanel10.add(o5, gridBagConstraints);

        o6.setForeground(new java.awt.Color(255, 255, 255));
        o6.setText("Loratadine");
        o6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o6ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 36;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 1);
        jPanel10.add(o6, gridBagConstraints);

        o7.setForeground(new java.awt.Color(255, 255, 255));
        o7.setText("Paracetamol");
        o7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o7ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.ipadx = 26;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        jPanel10.add(o7, gridBagConstraints);

        o8.setForeground(new java.awt.Color(255, 255, 255));
        o8.setText("Supertetra");
        o8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o8ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.ipadx = 36;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 1);
        jPanel10.add(o8, gridBagConstraints);

        o9.setForeground(new java.awt.Color(255, 255, 255));
        o9.setText("Vitamin C");
        o9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o9ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.ipadx = 40;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        jPanel10.add(o9, gridBagConstraints);

        o10.setForeground(new java.awt.Color(255, 255, 255));
        o10.setText("Ponstan");
        o10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                o10ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.ipadx = 48;
        gridBagConstraints.ipady = 63;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 1);
        jPanel10.add(o10, gridBagConstraints);

        jLabel23.setFont(new java.awt.Font("Kristen ITC", 1, 24)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("BELI ");

        jPanel9.setBackground(new java.awt.Color(0, 51, 153));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Nama :");
        jPanel9.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        Nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NamaActionPerformed(evt);
            }
        });
        jPanel9.add(Nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 150, -1));

        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Keluhan :");
        jPanel9.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));
        jPanel9.add(Keluhan, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 150, -1));

        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Total yang Harus dibayar :");
        jPanel9.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        TS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TSActionPerformed(evt);
            }
        });
        jPanel9.add(TS, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 150, -1));
        jPanel9.add(Uang, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 150, -1));

        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("Masukkan uang anda :");
        jPanel9.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, -1, -1));

        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Kembalian :");
        jPanel9.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        Kembalian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KembalianActionPerformed(evt);
            }
        });
        jPanel9.add(Kembalian, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 150, -1));

        jButton1.setText("Reset");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, -1));

        jButton2.setText("Bayar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 360, -1, -1));

        Kurang.setText("-");
        Kurang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KurangActionPerformed(evt);
            }
        });
        jPanel9.add(Kurang, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 40, -1));
        jPanel9.add(Jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 60, -1));

        Tambah.setText("+");
        Tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TambahActionPerformed(evt);
            }
        });
        jPanel9.add(Tambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 40, -1));

        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Jumlah");
        jPanel9.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        jLabel31.setFont(new java.awt.Font("Kristen ITC", 1, 24)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("NOTA");

        Nota.setColumns(20);
        Nota.setRows(5);
        jScrollPane1.setViewportView(Nota);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(87, 87, 87)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(123, 123, 123)
                                .addComponent(jLabel2))
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 459, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(53, 53, 53)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addComponent(jLabel20)
                                        .addGap(118, 118, 118)
                                        .addComponent(jLabel23)
                                        .addGap(166, 166, 166)
                                        .addComponent(jLabel31)))
                                .addGap(46, 46, 46)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGap(83, 83, 83)
                                .addComponent(jLabel20)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, 389, Short.MAX_VALUE)
                                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(76, 76, 76)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23)
                            .addComponent(jLabel31))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1)))
                .addGap(23, 23, 23))
        );

        jPanel3.add(jPanel7, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void o2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o2ActionPerformed
    harga = 10000;
    String detailObat = "Antasida: \nHarga: 20000\nDeskripsi: Mengatasi asam lambung berlebih, dan gangguan pencernaan\nDosis: 1-2 tablet saat gejala muncul";
        JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o2ActionPerformed

    private void NamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NamaActionPerformed

    private void KembalianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KembalianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_KembalianActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    
    if (!o1.isSelected() && !o2.isSelected() && !o3.isSelected() && !o4.isSelected()&& !o5.isSelected() && !o6.isSelected()
            && !o7.isSelected() && !o8.isSelected() && !o8.isSelected() && !o9.isSelected() && !o10.isSelected()){
        JOptionPane.showMessageDialog(ApotekMini.this,
                        "ANDA BELUM MEMILIH OBAT!",
                        "Message",
                        JOptionPane.WARNING_MESSAGE);
    }else if (Nama.getText().isEmpty()){
        JOptionPane.showMessageDialog(ApotekMini.this,
                        "ANDA BELUM MENGISI NAMA ANDA!",
                        "Message",
                        JOptionPane.WARNING_MESSAGE);
    }else if (Keluhan.getText().isEmpty()){
            JOptionPane.showMessageDialog(ApotekMini.this,
                        "ANDA BELUM MENGISI KELUHAN ANDA",
                        "Message",
                        JOptionPane.WARNING_MESSAGE);
    }else if (Jumlah.getText().isBlank()){
            JOptionPane.showMessageDialog(ApotekMini.this,
                        "ANDA BELUM MENGISI JUMLAH",
                        "Message",
                        JOptionPane.WARNING_MESSAGE);
    }else if (Uang.getText().isEmpty()){
        JOptionPane.showMessageDialog(ApotekMini.this,
                        "ANDA BELUM MEMASUKKAN NOMINAL UANG!",
                        "Message",
                        JOptionPane.WARNING_MESSAGE);
    }
    
    else {
    int totalHarga = 0;
    int jumlahBarang = Integer.parseInt(Jumlah.getText());

    // Cek checkbox yang dipilih dan tambahkan ke total harga
    if (o1.isSelected()) totalHarga += 10000; 
    if (o2.isSelected()) totalHarga += 10000; 
    if (o3.isSelected()) totalHarga += 15000; 
    if (o4.isSelected()) totalHarga += 15000; 
    if (o5.isSelected()) totalHarga += 10000; 
    if (o6.isSelected()) totalHarga += 20000; 
    if (o7.isSelected()) totalHarga += 5000;  
    if (o8.isSelected()) totalHarga += 10000; 
    if (o9.isSelected()) totalHarga += 2000;  
    if (o10.isSelected()) totalHarga += 25000; 

    
    totalHarga = totalHarga * jumlahBarang;
    TS.setText(String.valueOf(totalHarga));

    
    int totalsementara = totalHarga;
    int uangpembeli = Integer.parseInt(Uang.getText());

    if (uangpembeli < totalsementara) {
        JOptionPane.showMessageDialog(ApotekMini.this,
                "UANG YANG ANDA MASUKKAN TIDAK CUKUP!",
                "Message",
                JOptionPane.WARNING_MESSAGE);
    } else {
        
        int kembalian = uangpembeli - totalsementara;
        Kembalian.setText(String.valueOf(kembalian));  

       
        String obatDipilih = "";
        if (o1.isSelected()) obatDipilih += "Amoxilin (10000)\n";
        if (o2.isSelected()) obatDipilih += "Antasidadoen (10000)\n";
        if (o3.isSelected()) obatDipilih += "Cetrizine (5000)\n";
        if (o4.isSelected()) obatDipilih += "Dexametasone (15000)\n";
        if (o5.isSelected()) obatDipilih += "Ibuprofen (10000)\n";
        if (o6.isSelected()) obatDipilih += "Loratadine (20000)\n";
        if (o7.isSelected()) obatDipilih += "Paracetamol (5000)\n";
        if (o8.isSelected()) obatDipilih += "Supertetra (10000)\n";
        if (o9.isSelected()) obatDipilih += "Vitamin C (2000)\n";
        if (o10.isSelected()) obatDipilih += "Ponstan (25000)\n";

        
        String nota = "Nama Pembeli: " + Nama.getText() + "\n" +
                      "Keluhan: " + Keluhan.getText() + "\n" +
                      "Obat yang Dipilih:\n" + obatDipilih + 
                      "Total Pembayaran: Rp " + totalsementara + "\n" +
                      "Uang yang Diberikan: Rp " + uangpembeli + "\n" +
                      "Kembalian: Rp " + kembalian;

        
        Nota.setText(nota);

        
        JOptionPane.showMessageDialog(ApotekMini.this,
                "PEMBAYARAN BERHASIL!",
                "INFORMASI",
                JOptionPane.INFORMATION_MESSAGE);
    }
    }
    
    
        
    
    
    
    
    
    
    }//GEN-LAST:event_jButton2ActionPerformed

    private void KurangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KurangActionPerformed
    if (jumlah > 1) {
                    jumlah--;
                    Jumlah.setText(String.valueOf(jumlah));
                }    
    }//GEN-LAST:event_KurangActionPerformed

    private void o3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o3ActionPerformed
    harga = 5000;
    String detailObat = "Antasida: \nHarga: 20000\nDeskripsi: Mengatasi asam lambung berlebih, dan gangguan pencernaan\nDosis: 1-2 tablet saat gejala muncul";
        JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o3ActionPerformed

    private void TambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TambahActionPerformed
    jumlah++;
                Jumlah.setText(String.valueOf(jumlah));
    int totalHarga = 0;
    
    int jumlahBarang = Integer.parseInt(Jumlah.getText()); 
    
    if (o1.isSelected()) {
        totalHarga += 10000; 
    }
    if (o2.isSelected()) {
        totalHarga += 10000; 
    }
    if (o3.isSelected()) {
        totalHarga += 15000; 
    }
    if (o4.isSelected()) {
        totalHarga += 15000; 
    }
    if (o5.isSelected()) {
        totalHarga += 10000; 
    }
    if (o6.isSelected()) {
        totalHarga += 20000; 
    }
    if (o7.isSelected()) {
        totalHarga += 5000; 
    }
    if (o8.isSelected()) {
        totalHarga += 10000; 
    }
    if (o9.isSelected()) {
        totalHarga += 2000;  
    }
    if (o10.isSelected()) {
        totalHarga += 25000; 
    }

   
    totalHarga = totalHarga * jumlahBarang;

   
    TS.setText(String.valueOf(totalHarga));
              
       
            
                                    
    }//GEN-LAST:event_TambahActionPerformed

    private void o1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o1ActionPerformed
    harga = 10000;
    String detailObat = "Amoxcillin: \nHarga: 10000\nDeskripsi: Antibiotik untuk infeksi tenggorokan, saluran pernapasan\nDosis: 500 mg 3 kali sehari selama 7 hari";
        JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o1ActionPerformed

    private void o4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o4ActionPerformed
    harga = 15000;
    String detailObat = "Dexamethasone: \nHarga: 5000\nDeskripsi: Steroid untuk mengatasi peradangan dan alergi berat\nDosis: 0.5-4 mg per hari";
        JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o4ActionPerformed

    private void o5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o5ActionPerformed
    harga = 10000;
    String detailObat = "IbuProfen: \nHarga: 10000\nDeskripsi: Meredakan nyeri, peradangan, dan demam\nDosis: 400-600 mg setiap 6-8 jam";
         JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o5ActionPerformed

    private void o6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o6ActionPerformed
    harga = 20000;
    String detailObat = "Loratadine: \nHarga: 15000\nDeskripsi: Mengatasi alergi seperti pilek alergi dan gatal-gatal\nDosis: 10 mg sekali sehari";
        JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o6ActionPerformed

    private void o7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o7ActionPerformed
    harga = 5000;
    String detailObat = "Paracetamol: \nHarga: 12000\nDeskripsi: Meredakan sakit kepala,demam\nDosis: 500 mg setiap 4-6 jam";
        JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o7ActionPerformed

    private void o8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o8ActionPerformed
    harga = 10000;
    String detailObat = "Supertetra: \n" +"Harga: 15000\n" +"Deskripsi: Obat antibiotik yang digunakan untuk mengobati infeksi bakteri, seperti infeksi saluran pernapasan, kulit, dan infeksi telinga.\n" +"Dosis: 250 mg setiap 8 jam, sesuai petunjuk dokter.";
        JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o8ActionPerformed

    private void o9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o9ActionPerformed
    harga = 2000;
    String detailObat = "Vitamin C: \n" +
"Harga: 5000\n" +
"Deskripsi: Suplemen yang digunakan untuk meningkatkan sistem kekebalan tubuh, mencegah defisiensi vitamin C, serta berfungsi sebagai antioksidan yang melindungi sel-sel tubuh dari kerusakan.\n" +
"Dosis: 500 mg sehari, bisa dibagi menjadi dua dosis, sesuai anjuran dokter.";
        JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o9ActionPerformed

    private void o10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_o10ActionPerformed
    harga = 25000;
    String detailObat = "Ponstan: \n" +
"Harga: 25000\n" +
"Deskripsi: Obat anti-inflamasi non-steroid (NSAID) yang digunakan untuk meredakan nyeri, seperti nyeri haid, nyeri gigi, dan nyeri otot, serta untuk mengurangi peradangan.\n" +
"Dosis: 500 mg tiga kali sehari setelah makan, sesuai anjuran dokter.";
        JOptionPane.showMessageDialog(null, detailObat, "Detail Obat:", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_o10ActionPerformed

    private void TSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TSActionPerformed
    
    }//GEN-LAST:event_TSActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    o1.setSelected(false);
    o2.setSelected(false);
    o3.setSelected(false);
    o4.setSelected(false);
    o5.setSelected(false);
    o6.setSelected(false);
    o7.setSelected(false);
    o8.setSelected(false);
    o9.setSelected(false);
    o10.setSelected(false);
    Jumlah.setText("");
    Uang.setText("");
    Kembalian.setText("");
    TS.setText("");
    Nama.setText("");
    Keluhan.setText("");
    
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ApotekMini.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ApotekMini.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ApotekMini.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ApotekMini.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ApotekMini().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Jumlah;
    private javax.swing.JTextField Keluhan;
    private javax.swing.JTextField Kembalian;
    private javax.swing.JButton Kurang;
    private javax.swing.JTextField Nama;
    private javax.swing.JTextArea Nota;
    private javax.swing.JTextField TS;
    private javax.swing.JButton Tambah;
    private javax.swing.JTextField Uang;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JCheckBox o1;
    private javax.swing.JCheckBox o10;
    private javax.swing.JCheckBox o2;
    private javax.swing.JCheckBox o3;
    private javax.swing.JCheckBox o4;
    private javax.swing.JCheckBox o5;
    private javax.swing.JCheckBox o6;
    private javax.swing.JCheckBox o7;
    private javax.swing.JCheckBox o8;
    private javax.swing.JCheckBox o9;
    // End of variables declaration//GEN-END:variables
}
